# PG-CM GPU Experimental Stage

This package executes the remaining pretrained dense-retrieval experiment on
the exact fixtures from the completed structural run.

- `fixtures.jsonl`: 2,000 traces; SHA-256
  `c7fe0e27b17b963d4499fc08f441b8de9776196d455e616db5c6cb0dbffc1c23`.
- `source_run_manifest.json`: provenance for the accepted structural run.
- `hash_control_retrieval.json`: hash-control measurements used only for a
  matched comparison table.
- `pgcm_experiments/`: implementation, tests, embedding builder, verifier, and
  retrieval evaluator.
- `RUN_ON_KAGGLE.md`: exact notebook cells.

The neural run is supplementary to, not a replacement for, the structural
conformance experiment. Do not describe the generated fixtures as a
human-reviewed conversational benchmark or the local controls as published
memory systems.
