"""Create audited per-trace NPZ embeddings for Experiment 2.

Install explicitly in the notebook GPU stage:
  python -m pip install 'sentence-transformers>=3,<6' 'huggingface-hub>=0.25,<2'
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from pgcm.dataset import load_traces


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--model", default="BAAI/bge-small-en-v1.5")
    parser.add_argument("--revision", help="Pinned Hugging Face commit hash; strongly recommended for paper runs")
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--max-traces", type=int)
    args = parser.parse_args()
    if args.batch_size < 1: raise ValueError("positive batch size required")
    from sentence_transformers import SentenceTransformer
    from huggingface_hub import model_info
    info = model_info(args.model, revision=args.revision)
    resolved_revision = info.sha
    model = SentenceTransformer(args.model, revision=resolved_revision, device=args.device)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    count = 0
    for trace in load_traces(args.dataset):
        if args.max_traces is not None and count >= args.max_traces: break
        nodes = trace["graph"]["nodes"]
        queries = [item["query"] for item in trace["queries"]]
        record_ids = np.asarray([n["id"] for n in nodes], dtype=np.str_)
        query_ids = np.asarray([q["id"] for q in queries], dtype=np.str_)
        record_vectors = model.encode([n["text"] for n in nodes], batch_size=args.batch_size,
                                      convert_to_numpy=True, show_progress_bar=False)
        query_vectors = model.encode([q["text"] for q in queries], batch_size=args.batch_size,
                                     convert_to_numpy=True, show_progress_bar=False)
        target = out / f"{trace['trace_id']}.npz"
        np.savez_compressed(target, record_ids=record_ids, record_vectors=np.asarray(record_vectors,dtype=np.float32),
                            query_ids=query_ids, query_vectors=np.asarray(query_vectors,dtype=np.float32),
                            embedding_name=np.asarray(f"{args.model}@{resolved_revision}", dtype=np.str_))
        count += 1
    metadata = {"model": args.model, "requested_revision": args.revision,
                "resolved_revision": resolved_revision, "device": args.device,
                "batch_size": args.batch_size, "traces": count}
    (out / "embedding_manifest.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata, indent=2))

if __name__ == "__main__": main()
