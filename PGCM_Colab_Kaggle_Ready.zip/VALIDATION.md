# Package validation

The packaged source was validated before archiving:

- 21 unit/integration tests passed.
- 32,768 bounded four-node support configurations passed against the independent full-recomputation oracle.
- 2,000 randomized mixed activation/retraction steps passed.
- The quick notebook profile completed all phases: fixture generation, retrieval, actions, corruptions, concurrency, scalability, isolated gate timing, and dense affected-region timing.
- Python modules, tests, and helper scripts compiled successfully.
- The notebook JSON passed structural parsing.
- The final archive is checked member-by-member against `PACKAGE_SHA256.json`.

Validation was performed on Python 3.12.14 and NumPy 2.3.5. The declared minimum is Python 3.10 because the source uses only Python 3.10-compatible syntax and standard-library APIs, but this environment did not provide a second Python interpreter for a direct 3.10 execution test. The notebook fails early if its runtime is older than 3.10.

No finite validation can establish that software contains no errors. The pipeline fails closed on malformed graph inputs, stops on test or invariant failures, and records raw artifacts for independent review.
