# Start the PG-CM experiment

1. Extract this ZIP on your computer and open `RUN_PGCM_COLAB_KAGGLE.ipynb` in Colab, or upload the ZIP as a private Kaggle Dataset and upload the notebook to Kaggle.
2. Keep `PROFILE = "quick"` and `USE_GPU_EMBEDDINGS = False` for the first run.
3. Run every cell. The notebook installs the local package, checks the runtime, runs the complete tests, executes the experiment, reviews core outputs, and creates a downloadable result ZIP.
4. After the quick run passes, change `PROFILE = "full"` for the 2,000-trace structural run.
5. Use a T4 only for the optional Hugging Face embedding stage. Set an exact model revision for paper measurements.

Recommended platform: Kaggle for a reproducible saved CPU run and result version; Kaggle T4x2 for optional embedding generation if available. Colab T4 also works, but the current implementation uses one GPU and does not combine two 16-GB devices into 32 GB.

The code cannot guarantee the absence of every possible defect. It fails closed on malformed inputs, stops the pipeline when tests fail, preserves raw counts, records hashes, and labels model-dependent experiments as unexecuted until you run them.
