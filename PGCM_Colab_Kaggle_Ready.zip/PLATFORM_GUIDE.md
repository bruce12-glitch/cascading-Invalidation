# Colab or Kaggle?

## Recommendation for this experiment

Use **Kaggle CPU for the first quick and full structural PG-CM runs**. The support graph, SQLite, corruption, bootstrap, and concurrency experiments are implemented with Python/NumPy CPU operations. A T4 will remain idle during these phases.

Use **Kaggle T4x2 for the optional pretrained-embedding stage** when it is available. The supplied embedding generator currently uses one GPU; the second T4 provides no automatic speed or memory pooling. It can be extended later to shard independent traces across both devices. A single Colab T4 is also sufficient for the default small embedding model.

Choose **Colab T4** if interactive debugging and Google Drive are more useful to you than a versioned top-to-bottom run. Colab accelerator types and usage limits vary over time, so record the actual GPU and runtime from `runtime_preflight.json` in every experiment report.

## Current service facts checked on 8 October 2026

- Kaggle documents versioned notebook environments, `Save & Run All`, a 12-hour CPU/GPU execution limit, 20 GB autosaved working storage, and T4x2 sessions with two 16 GB GPUs and 29 GB system RAM.
- Kaggle announced that P100 availability ended on 15 September 2026 and identified T4x2 as the remaining general notebook accelerator at that time.
- Google states that Colab provides free GPU/TPU access. Its paid-services page states that accelerator types vary over time and sessions can run for at most 12 hours depending on availability and usage.

Sources:
- https://www.kaggle.com/docs/notebooks
- https://www.kaggle.com/product-announcements/735239
- https://developers.google.com/colab
- https://colab.research.google.com/signup

These quotas and hardware offerings can change. Check the runtime immediately before collecting publication results.
